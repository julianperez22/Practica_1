#include <iostream>
#include "math.h"
#include "string.h"
#include <stdlib.h>
#include <time.h>
using namespace std;

//      PROBLEMA 1
/*int main()
{
    int din,b50=0,b20=0,b10=0,b5=0,b2=0,b1=0,m5=0,m2=0,m1=0,m50=0;
    cout<<"Ingrese el dinero";
    cin>>din;
    if (din/50000>=1){
        b50=din/50000;
        din=din%50000;
    }
    if (din/20000>=1){
        b20=din/20000;
        din=din%20000;
    }
    if (din/10000>=1){
        b10=din/10000;
        din=din%10000;
    }
    if (din/5000>=1){
        b5=din/5000;
        din=din%5000;
    }
    if (din/2000>=1){
        b2=din/2000;
        din=din%2000;
    }
    if (din/1000>=1){
        b1=din/1000;
        din=din%1000;
    }
    if (din/500>=1){
        m5=din/500;
        din=din%500;
    }
    if (din/200>=1){
        m2=din/200;
        din=din%200;
    }
    if (din/100>=1){
        m1=din/100;
        din=din%100;
    }
    if (din/50>=1){
        m50=din/50;
        din=din%50;
    }
    cout<<"50000:"<<b50<<endl;
    cout<<"20000:"<<b20<<endl;
    cout<<"10000:"<<b10<<endl;
    cout<<"5000:"<<b5<<endl;
    cout<<"2000:"<<b2<<endl;
    cout<<"1000:"<<b1<<endl;
    cout<<"500:"<<m5<<endl;
    cout<<"200:"<<m2<<endl;
    cout<<"100:"<<m1<<endl;
    cout<<"50:"<<m50<<endl;
    cout<<"Restante:"<<din<<endl;
}*/


//      PROBLEMA 3
/*int main()
{
    int dias[12]={31,28,31,30,31,30,31,31,30,31,30,31};
    int mes,dia;
    cout<<"Ingrese el mes";
    cin>>mes;
    cout<<"Ingrese el dia";
    cin>>dia;
    if (mes>12 or mes<1) cout<<mes<<" es un mes invalido."<<endl;
    else {
        if (dia>0 and dia<=dias[mes-1]) cout<<dia<<"/"<<mes<<" es una fecha valida."<<endl;
        else if (mes==2 and dia==29) cout<<dia<<"/"<<mes<<" es valida en bisiesto."<<endl;
        else cout<<dia<<"/"<<mes<<" es una fecha invalida."<<endl;
    }
}*/

//        PROBLEMA 5
/*int main()
{
    int lon,nesp,nast=1;
    cout << "Ingrese un numero entero impar" << endl;
    cin>>lon;
    string a="*",esp=" ";
    nesp=lon/2;
    while (nesp>=0){
        for (int i=1;i<=nesp;i++){
            cout<<esp;
        }
        for (int i=1;i<=nast;i++){
            cout<<a;
        }
        for (int i=1;i<=nesp;i++){
            cout<<esp;
        }
        cout<<endl;
        nast=nast+2;
        nesp--;
    }
    nesp=1;
    nast=nast-4;
    while (nesp<=lon/2){
        for (int i=1;i<=nesp;i++){
            cout<<esp;
        }
        for (int i=1;i<=nast;i++){
            cout<<a;
        }
        for (int i=1;i<=nesp;i++){
            cout<<esp;
        }
        cout<<endl;
        nast=nast-2;
        nesp++;
    }
    return 0;
}*/

//        PROBLEMA 7
/*int main()
{
    int n1=1,n2=1,rest=0,num,n3;
    cout<<"Ingrese un numero";cin>>num;
    while (n2<=num){
        //cout<<n3<<n2<<n1<<endl;
        if ((n2%2)==0){
            rest=rest+n2;
        }
        n3=n1+n2;
        n1=n2;
        n2=n3;
    }
    cout<<"El resultado de la suma es "<<rest<<endl;
    return 0;
} */

//        PROBLEMA 8
/*int main()
{

    int n1=0,n2=0,n3=0,mult=0,suma=0;
    cout<<"Ingrese 3 numeros";cin>>n1>>n2>>n3;
    mult=n1;
    for(int i=n1;i<n3;){
        if (n1<n3)
            suma=suma+i;
            n1=n1+mult;
            i=n1;
            cout<<n1<<"+";
    }
    mult=n2;
    for(int t=n2;t<n3;){
        if (n2<n3)
            suma=suma+t;
            n2=n2+mult;
            t=n2;
            cout<<n2<<"+";

    }
    cout<<"="<<suma;



    return 0;
} */


//      PROBLEMA 9
/*int lon(int);
int main()
{
    int num,l,rest=0,dig;
    cout << "Ingrese un numero" << endl;cin>>num;
    l=lon(num);
    while (l>0){
        dig=num%10;
        rest=rest+pow(dig,dig);
        num=num/10;
        l--;
    }
    cout<<rest<<endl;
    return 0;
}
int lon(int num){
    int lon=0;
    while (num>0){
       num=num/10;
       lon++;
    }
    return lon;
}*/

// PROBLEMA 13
/*int main()
{

    int num=0;cout<<"Ingrese un numero "; cin>>num;
    int num2=num,p=0,i=0;


    for (int i=2;num>1;i++){
        while (num%i==0){
            num/=i;
            p=i;

        }

    }
    cout<<"El mayor factor primo de  "<<num2<<"es "<<p;
    return 0;
}*/


// PROBLEMA 13
/*int main()
{
    int num,total=0;
    cout << "Ingrese un numero" << endl;cin>>num;
    for (int i=2;i<=num;i++){
        int var=1;
        for (int j=2;j<i;j++){
            if (i%j==0) var=0;
        }
        if (var==1) total=total+i;
    }
    cout<<total<<endl;
    return 0;
}*/


//       PROBLEMA 15
/*int main()
{
    int num,sum,rest;
    cout << "Ingrese un numero impar" << endl;cin>>num;
    cout<<"Es una espiral "<<num<<"x"<<num<<", la suma es: ";
    int numm=num*num;
    sum=numm;
    rest=num-1;
    for (;rest>0;rest=rest-2){
        for(int i=1;i<=4;i++){
            numm=numm-rest;
            sum=sum+numm;
        }
    }
    cout<<sum<<endl;
    return 0;
}*/

//      PROBLEMA 17
/*int main()
{
    int k,nd=0,n=1;
    cout << "Ingrese un numero" << endl; cin>>k;
    int j=(n*(n+1)/2);
    while (nd<=k){
        j=(n*(n+1))/2;
        nd=0;
        for (int i=1;i<=j;i++){
            if (j%i==0) nd++;
        }
        n++;
        //cout<<j<<endl<<n;
    }
    cout<<"El numero es: "<<j<<" que tiene "<<nd<<" divisores."<<endl;
    return 0;
}*/
